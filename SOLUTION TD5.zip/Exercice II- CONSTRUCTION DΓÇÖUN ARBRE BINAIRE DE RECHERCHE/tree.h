#include <iostream>
#include <queue>
#include <stack>
using namespace std;

// Définition du noeud en tant que structure (struct)
struct noeud {
    int cle;
    noeud *gauche; // Noeud fils gauche
    noeud *droit;  // Noeud fils droit
};

class Arbre {
private:
    noeud *racine; // Racine de l'arbre
    int compteur;  // Compteur du nombre de noeuds dans l'arbre

    noeud* newNoeud(const int valeur); // Créer un nouveau noeud et retourner un pointeur vers ce noeud
    void detruire(noeud *ptr); // Détruire le noeud et ses sous-arbres
    void inserer(const int valeur, noeud *&ptr); // Insérer une valeur dans l'arbre de manière récursive

public:
    Arbre(); // Constructeur par défaut qui initialise un arbre vide
    ~Arbre(); // Destructeur par défaut

    void ArbreVide(); // Vider l'arbre
    void inserer(const int valeur); // Insérer une valeur dans l'arbre
    void parcoursLargeur(); // Parcourir l'arbre en largeur
    void parcoursProfondeur(); // Parcourir l'arbre en profondeur
};

// Constructeur
Arbre::Arbre() : racine(nullptr), compteur(0) {}

// Destructeur
Arbre::~Arbre() {
    detruire(racine);
}

// Fonction récursive pour détruire un noeud et ses sous-arbres
void Arbre::detruire(noeud *ptr) {
    if (!ptr) return;

    detruire(ptr->gauche); // Détruire le sous-arbre gauche
    detruire(ptr->droit);  // Détruire le sous-arbre droit
    delete ptr;            // Détruire le noeud courant
}

// Vider l'arbre
void Arbre::ArbreVide() {
    racine = nullptr;
    compteur = 0;
}

// Insérer une valeur dans l'arbre
void Arbre::inserer(const int valeur) {
    inserer(valeur, racine);
    compteur++;
}

// Fonction récursive pour insérer une valeur dans l'arbre
void Arbre::inserer(const int valeur, noeud *&ptr) {
    // Si l'arbre est vide ou si nous avons atteint un noeud terminal, créer un nouveau noeud
    if (!ptr) {
        ptr = new noeud;
        ptr->cle = valeur;
        ptr->gauche = nullptr;
        ptr->droit = nullptr;
    }
    // Si la valeur à insérer est inférieure à la valeur du noeud courant, insérer à gauche
    else if (valeur < ptr->cle) {
        inserer(valeur, ptr->gauche);
    }
    // Sinon, insérer à droite
    else {
        inserer(valeur, ptr->droit);
    }
}

// Créer un nouveau noeud avec une valeur donnée
noeud *Arbre::newNoeud(const int valeur) {
    noeud *temp = new noeud;
    temp->cle = valeur;
    temp->gauche = nullptr;
    temp->droit = nullptr;
    return temp;
}

// Parcourir l'arbre en largeur
void Arbre::parcoursLargeur() {
    /*
     * ALGORITHME PARCOURS EN LARGEUR:
     * 1- Commencer par le noeud racine de l'arbre: Ajouter le nœud racine à une file.
     * 2- Tant que la file n'est pas vide :
     *     - Retirer un noeud de la file.
     *     - Traiter ce noeud (afficher sa valeur).
     *     - Ajouter tous les noeuds enfants (1seul niveau)du noeud traité à la file.
     * 3- Répéter l'étape 2 jusqu'à ce que la file soit vide.
     */

    if (!this->racine) {
        return; // Si l'arbre est vide, sortir de la fonction
    }

    queue<noeud*> file; // File pour le parcours en largeur
    file.push(this->racine); // Ajouter la racine à la file

    while (!file.empty()) {
        noeud* elem_courant = file.front(); // Récupérer le nœud en tête de file
        file.pop(); // Retirer le noeud de la file
        cout << elem_courant->cle << " "<<endl; // Afficher la valeur du nœud

        // Ajouter les noeuds enfants à la file
        if (elem_courant->gauche != nullptr) {
            file.push(elem_courant->gauche);
        }
        if (elem_courant->droit != nullptr) {
            file.push(elem_courant->droit);
        }
    }
    cout << endl;
}

// Parcourir l'arbre en profondeur
void Arbre::parcoursProfondeur() {
    /*
     * ALGORITHME PARCOURS EN PROFONDEUR:
     * 1- Initialiser une pile avec la racine de l'arbre.
     * 2- Tant que la pile n'est pas vide:
     *     - Dépiler le noeud du sommet de la pile (dernier noeud inséré).
     *     - Traiter ce noeud (afficher sa valeur).
     *     - Empiler ses enfants droit puis gauche pour garantir que le sous-arbre gauche est exploré en premier.
     *
     * NB: L'utilisation de la pile (stack) est nécessaire car elle traite toujours en premier le dernier élément ajouté (LIFO).
     * Cela garantit que nous explorons d'abord les enfants les plus profonds d'un noeud avant de remonter vers ses enfants plus proches de la racine.
     */

    if (!racine) return; // Si l'arbre est vide, sortir de la fonction

    stack<noeud*> pile;
    pile.push(racine); // Ajouter la racine à la pile

    while (!pile.empty()) {
        noeud* elem_courant = pile.top(); // Récupérer le noeud au sommet de la pile
        pile.pop(); // Retirer le noeud de la pile

        cout << elem_courant->cle << endl; // Afficher la valeur du noeud

        // Ajouter les noeuds enfants à la pile
        if (elem_courant->droit) { // Empiler d'abord le fils droit
            pile.push(elem_courant->droit);
        }
        if (elem_courant->gauche) { // Puis empiler le fils gauche
            pile.push(elem_courant->gauche);
        }
    }
}
