#include <iostream>
#include "tree.h"
#include <list>

struct Etudiant{
    int nMachine;
    string NomEtd;
};

int main(){
// créer des étudiants
	Etudiant e1,e2,e3,e4,e5;
	e1.NomEtd="bob";
	e1.nMachine=8;
	e2.NomEtd="Brice";
	e2.nMachine=1;
	e3.NomEtd="Alice";
	e3.nMachine=3;
	e4.NomEtd="Imane";
	e4.nMachine=9;
	e5.NomEtd="Adam";
	e5.nMachine=2;

    list <Etudiant> LE;
    //Ajouter les étudiants à la liste LE
    LE.push_back(e1);
    LE.push_back(e2);
    LE.push_back(e3);
    LE.push_back(e4);
    LE.push_back(e5);


    Arbre A;// Créer une instance de l'arbre
    A.ArbreVide(); // Initialiser l'arbre comme étant vide

    // Insérer les étudiants de la liste dans l'arbre
    auto it = LE.begin();//déclaration de l'iterateur "it" pour parcourir la liste LE
      for (int i=0;i<LE.size();i++) {
            A.inserer(it->nMachine);
            it++;
        }
cout<<"Liste des sommets d’un parcours en largeur"<<endl;
A.parcoursLargeur();

cout<<"Liste des sommets d’un parcours en profondeur"<<endl;
A.parcoursProfondeur();

}



