/*En supposant définies les primitives Insérer,
Supprimer, Lire, et Longueur du composant de liste, écrire un programme qui
« nettoie » une liste en ne laissant qu'une seule occurrence de chaque élément*/

#include <iostream>
#include <list> // important
#include <stack> // important
#include <time.h>

using namespace std;

/** EXERCICE 1 **/
void nettoie(list<int> &l)
{
	auto it1=l.begin();

	while(it1!=l.end())
	{
		auto it2=it1;
		it2++;
		while(it2!=l.end())
			{
			if(*it1==*it2)
				{

				it2=l.erase(it2);// A EXPLIQUER Prk
				}
			else it2++;
			}
	it1++;
	}
}

void afficherListe(list<int> l)
{
	for (int e: l)
		{
			cout<<e<<endl;
		}
}

/** EXERCICE 2 **/
void inserer(stack<int> &s, int x)
{
	stack<int> TEMP;
	if(s.empty())
	{
	s.push(x);

	}

	else
	{

		TEMP.push(s.top());//inserer l element au sommet de s dans temp
		//char f=s.top();
		s.pop();//supprimer l element au sommet
		inserer(s,x);

		while(!TEMP.empty())
		{
			s.push(TEMP.top());//supprimer l element au sommet
			TEMP.pop();

		}
	}
}
void transvaser(stack<int> temp, stack<int> &s1)
{
		while(!temp.empty())
			{
						int x=temp.top();
						temp.pop();
						s1.push(x);

			}
}
/* ********* ALGO 1 : Inverser une pile en utilisant la récursion et une pile temporaire ***********

Algorithme Inverser(Pile s)
  Si Taille(s) > 0 alors
    x ← Sommet(s)    // Lire l'élément au sommet de la pile
    Dépiler(s)       // Supprimer l'élément au sommet de la pile
    Inverser(s)      // Appel récursif pour inverser le reste de la pile
    Insérer(s, x)    // Insérer l'élément x au bas de la pile (fonction auxiliaire)
  FinSi
FinAlgorithme

Algorithme Insérer(Pile s, Entier x)
  Déclarer TEMP comme Pile
  Si PileVide(s) alors
    Empiler(s, x)    // Ajouter l'élément x au sommet de la pile
  Sinon
    Empiler(TEMP, Sommet(s))  // Déplacer l'élément du sommet de s à TEMP
    Dépiler(s)       // Supprimer l'élément du sommet de s
    Insérer(s, x)    // Appel récursif pour insérer x au bas de s
    TantQue Non PileVide(TEMP) faire
      Empiler(s, Sommet(TEMP)) // Remettre les éléments de TEMP dans s
      Dépiler(TEMP)   // Supprimer l'élément du sommet de TEMP
    FinTantQue
  FinSi
FinAlgorithme
 */
/* FONCTION inverse suivant ALGO 1 :
void inverse(stack<int> &s)
{
	int taille=s.size();
	if(taille>0) //if !s.empty()
	{

				int x=s.top();
				s.pop();
				inverse(s);
				inserer(s,x);// appel recursif de la fonction inverse

	}
}
****************************************************/
/************ ALGO 2: Inverser une pile en utilisant une deuxième pile **********
 Algorithme Inverser(Pile s) retourner Pile s2
 Déclarer s2 comme Pile  // Pile temporaire pour stocker les éléments inversés
 TantQue Non PileVide(s) faire
   x ← Sommet(s)    // Lire l'élément au sommet de s
   Dépiler(s)       // Supprimer l'élément du sommet de s
   Empiler(s2, x)   // Ajouter l'élément x au sommet de s2
 FinTantQue
 Retourner s2
FinAlgorithme

 */
/* FONCTION inverse suivant ALGO 2 : */
stack<int> inverse(stack<int> &s)
{

	stack<int> s2;
	//transvaser s dans s2
	while(!s.empty())
	{
				int x=s.top();

				s.pop();
				s2.push(x);
	}
	return s2;



}

void afficherPile(stack<int> st)
{ stack<int> p = st;
	while(!p.empty()) {
			cout<< p.top()<<endl;
			p.pop();
		}
		cout<<endl;
}
/******************************/
/** EXERCICE 3 **/
int main()
{
	list<int> maliste;
	maliste.push_back(10);
	maliste.push_back(10);
	maliste.push_back(30);
	maliste.push_front(9);
	maliste.push_front(10);

	nettoie(maliste);
	cout<<"Contenu de la liste: "<<endl;
	afficherListe(maliste);
	cout<<endl;

	stack<int> s;
	s.push(1);
	s.push(2);
	s.push(4);
	cout<<"Contenu de la pile avant inversion: "<<endl;
	afficherPile(s);
	s=inverse(s);
	cout<<"Contenu de la pile après inversion: "<<endl;
	afficherPile(s);
return 0;
}
