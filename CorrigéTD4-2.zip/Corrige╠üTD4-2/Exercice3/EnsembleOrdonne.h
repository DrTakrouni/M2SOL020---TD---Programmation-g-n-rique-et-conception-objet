
/* 2- Exercice 3  : Écrire le code d’EnsembleOrdonne. On souhaite instancier ce patron avec la classe Date. Que faut-il faire ? Tester.

 	 * Modifications à apporter :
 	 * (1) Modifier la portée des attributs de la classe mère de Private à Protected
 	 * (2) Ajouter un constructeur par défaut dans la classe Date
 	 * (3) Ajouter une fonction de surcharge de l'opérateur < pour comparer deux objets de type Dates (utilisée par la fonction AjouterElm)

*/
#include "Ensemble.h"

template <typename T> class EnsembleOrdonne : public Ensemble<T> {


	public:
	EnsembleOrdonne():Ensemble <T> (){}
	void permuter(T &e1, T &e2)
	{
		T temp=e1;
		e1=e2;
		e2=temp;

	}
	 // Redéfinition de la méthode AjoutElm pour insérer dans l'ordre croissant
	/*APPROCHE 1:
	 * vérifier d'abord si le tableau est vide:
	 * Si c'est le cas, insérer simplement l'élément dans la première case et quittez la fonction.
	 * Sinon: parcourir le tableau pour trouver la première case vide. Si trouvée:
	 *  insérer l'élément et parcourir le tableau à l'envers en permutant à chaque fois les deux cases
	 *  contiguës pour maintenir l'ordre croissant des éléments.
	 */
	void AjoutElm(T elem)  // Trouver la première case vide et insérer l'élément en maintenant l'ordre
    {	//Si le tableau elements est vide, on insere l'élément dans la première case puis on quitte la fonction
    	if (this->elements[0]==T()) {
    		this->elements[0]=elem;
    		return;
    	}
		// Trouver la première case vide et insérer l'élément en maintenant l'ordre croissant
		        for (int i = 0; i < this->size; ++i) {

		            if (this->elements[i] == T()) { // Vérifier si l'élément à la position i est vide
		                // Insérer l'élément à la position vide puis parcourir le tableau Element à l'envers
		            	this->elements[i]=elem;
		            	int j=i;
		            	while(j>=0 && this->elements[j]<this->elements[j-1]) // comparaison des valeurs des deux cases contiguës (nécessite la modification (3) dans le cas d'un objet de type Date)
		            	{
		            		permuter(this->elements[j],this->elements[j-1]);
		            		j--;
		            	}
		            	break;// ATTENTION: l'utilisation de break ici est impérative pour forcer la sortie de la boucle et éviter l'insertion de l'élément "elem" dans toutes les cases vides du tableau
		            }
		            else{
		            	//Impossible d'ajouter un élement car le tableau est plein
		            }
		        }
		    }
/* APPROCHE 2
 * Parcourir le tableau pour trouver une position d'insertion:
	 * 	Si une case vide est trouvée lors de la recherche, l'élément est inséré directement à cette position.
	 * 	Sinon, si la position d'insertion est située entre deux éléments existants:
		 * 	les éléments situés après cette position sont déplacés vers la droite pour faire de la place pour le nouvel élément,
		 * 	puis l'élément est inséré à la position trouvée.
 */
 /* void AjoutElm(T elem) {

		    int insertPos = 0;
		    // Trouver la position d'insertion en parcourant le tableau
		    for (insertPos = 0; insertPos < this->size; ++insertPos) {
		        if (this->elements[insertPos] == T()) {
		            // Si on trouve une case vide, insérer directement l'élément à cette position, puis sortir de la fct
		            this->elements[insertPos] = elem;
		            return;
		        }
		        else if (elem < this->elements[insertPos]) {
		            // Si l'élément à insérer est inférieur à l'élément actuel, on a trouvé la position d'insertion
		            break;
		        }
		    }

		    // Décaler les éléments vers la droite pour faire de la place pour l'élément inséré
		    for (int i = this->size - 1; i > insertPos; --i) {
		        this->elements[i] = this->elements[i - 1];
		    }

		    // Insérer l'élément à la position trouvée
		    this->elements[insertPos] = elem;
		}
//FIN AJOUTERELM() - APPROCHE2
*/



};

