#include <iostream>
#include "EnsembleOrdonne.h"
#include "Date.h"

using namespace std;
int main()
{
Carafe c1(1,0);
Carafe c2(3,1);
Carafe c3(18,23);
Ensemble<Carafe> e;//Initialisation du patron de classe Ensemble avec la classe Carafe; ceci implique l'initialisation du tableau "element" de la classe Ensemble par des objets vides de type Carafe
Ensemble<Carafe> e2;
Ensemble<Carafe> e1;

e.AjoutElm(c1);
e.AjoutElm(c3);
e2.AjoutElm(c2);
e2.AjoutElm(c1);
cout<<"Contenu du tableau element après l'ajout d'objets de type Carafe : "<<endl;
e.Afficher();
e2.Afficher();
e.DetruireElm(c2);
cout<<"Contenu du tableau element après suppression d'un objet: "<<endl;
e.Afficher();
cout<<"Contenu du tableau element après suppression d'un objet: "<<endl;
e2.Afficher();
if(e.isSubset(e2)==true)
	{
	cout<<"l'ensemble 2 est un sous-ensemble de l'ensemble 1 "<<endl;
	}
cout<<"RÉSULTAT UNION :"<<endl;
e1=e.buildunion(e2);
e1.Afficher();
e1=e.getIntersection(e2);
cout<<"RÉSULTAT INTERSECTION: "<<endl;
e1.Afficher(); //NOTEZ QUE LES CASES VIDES DU TABLEAU ELEMENT SERONT REMPLIES PAR DES OBJETS AVEC UNE VALEUR DE 0.0

Date d1(01,01,2021);
Date d2(01,01,2020);
Date d3(01,10,2020);

EnsembleOrdonne<Date>eo1; //NB: N'oubliez pas d'ajouter le constructeur par défaut dans la classe Date, car celui-ci sera appelé implicitement par le constructeur Ensemble() dans Ensemble.h
eo1.AjoutElm(d1);
cout<<"Contenu du tableau après l'ajout d'une date: "<<endl;
eo1.Afficher();
eo1.AjoutElm(d2);
cout<<"Contenu du tableau après l'ajout d'une date: "<<endl;
eo1.Afficher();
eo1.AjoutElm(d3);
cout<<"Contenu du tableau après l'ajout d'une date: "<<endl;
eo1.Afficher();


return 0;

}
