#include <iostream>
using namespace std;
#include "Carafe.h"


template <typename T> class Ensemble{
protected:
    static const  size_t size = 3;
    T elements[size]; // Tableau nommé elements de type générique T et de taille constante 3
public:
    //Initialisation des élements du tableau "elements"
    Ensemble(){
    	for(int i=0;i<size;i++)
    		{
    	       elements[i]=T();//initialiser les elements du tableau par des objets vides de type T (role du constructeur par défaut T())
    		}
    }
    // Ajout d'un élément au tableau "elements" en recherchant la première case vide
	void AjoutElm(T elem) {
        for(int i=0;i<size;i++)
        {
        	if(elements[i]==T()) //vérifier si l'élément à la position i est vide
        	{
        		elements[i] = elem; // Ajouter l'élément à la position i
        		break; // ATTENTION: l'utilisation de break ici est impérative pour forcer la sortie de la boucle et éviter l'insertion de l'élément "elem" dans toutes les cases du tableau
        	}
        	else
          		{

          		}
        }

    }
	//Destruction d'un élément
	void DetruireElm(T elem){
		for(int i=0;i<size;i++)
		        {
			if (elements[i]==elem)// si l'élément à la position i est celui recherché...
				elements[i]=T(); // remplacer son ancienne valeur par un objet vide de type générique T
		        }

	}
	//Affichage du contenu du tableau element
	void Afficher()
	{
		for(int i=0;i<size;i++)
				        {
						cout<<elements[i]<<endl;
				        }

	}


	//inclusion

bool isSubset(Ensemble b){

	        for (int i=0;i<size;i++){
	            for (int j = 0; j < size; j++){
	                if (this->elements[i] == b.elements[j]){
	                	return true;
	                }
	            }
	        }
	    return false;
	}
//union
Ensemble buildunion(Ensemble b){
		Ensemble e;
		for(int i=0;i<size;i++)
			{
			e.AjoutElm(this->elements[i]);
			e.AjoutElm(b.elements[i]);
			}
	    return e;
	}



//intersection
Ensemble getIntersection(Ensemble b){
		Ensemble e;
		for(int i=0;i<size;i++)
			{for(int j=0;j<size;j++)
			{
			  if (this->elements[i] == b.elements[j]){
				       e.AjoutElm(b.elements[j]);

				                }
			}
			}
	    return e;
	}


};


