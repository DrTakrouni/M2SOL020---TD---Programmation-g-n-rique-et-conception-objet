#include <iostream>
#include "Carafe.h"
using namespace std;

Carafe::Carafe(){
	this->contenu = 0;
	this->capacite  = 0;
}
Carafe::Carafe(int contenu,int capacite) {
    		this->contenu = contenu;
    		this->capacite  = capacite;
    	}
	ostream& operator<<(ostream& os,Carafe& c ){

    	os<<c.Contenu()<<"-"<<c.Capacite();
    	return os;

    }
Carafe* Carafe::operator+=(int qte)
{if(this->contenu+qte<=this->capacite)
	this->contenu=qte;
else this->contenu=capacite;
	return this;
}
Carafe* Carafe::operator-=(int)
{

		this->contenu=0;

	return this;
}
 int Carafe::Contenu() {
     		return contenu;
     	}
    int Carafe::Capacite() {
     		return capacite;
     	}
 void Carafe::transvaser(Carafe c) {
     		if (((contenu + c.contenu) <= c.capacite)) {
     			c.contenu += contenu;
     			contenu = 0;
     		}
     		else{
     			contenu -= (c.capacite - c.contenu);
     			c.contenu = c.capacite;
     		}
     }
Carafe Carafe::operator+=(Carafe c) // c+=this
		{
	if (((contenu + c.contenu) <= c.capacite)) {
	     			c.contenu += contenu;
	     			contenu = 0;
	     		}
	     		else{
	     			this->contenu -= (c.capacite - c.contenu);
	     			c.contenu = c.capacite;
	     		}
		return c;
		}
bool Carafe::operator==(Carafe c)
		{
	if (contenu==c.contenu and capacite==c.capacite)
			return true;
	else
			return false;
		}
