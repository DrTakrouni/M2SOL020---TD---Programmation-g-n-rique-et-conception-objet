#include <iostream>                                                                                                                                                                                          
#include "Ensemble.h"                                                                                                                                                                                        
using namespace std;                                                                                                                                                                                         
                                                                                                                                                                                                             
int main()                                                                                                                                                                                                   
{                                                                                                                                                                                                            
Carafe c1(1,0);                                                                                                                                                                                              
Carafe c2(3,1);                                                                                                                                                                                              
Carafe c3(18,23);                                                                                                                                                                                            
Ensemble<Carafe> e;//Initialisation du patron de classe Ensemble avec la classe Carafe; ceci implique l'initialisation du tableau "elements" de la classe Ensemble par des objets vides de type Carafe       
Ensemble<Carafe> e2;                                                                                                                                                                                         
Ensemble<Carafe> e1;                                                                                                                                                                                         
                                                                                                                                                                                                             
//Ajout d'un élément                                                                                                                                                                                         
e.AjoutElm(c1);                                                                                                                                                                                              
e.AjoutElm(c3);                                                                                                                                                                                              
e2.AjoutElm(c2);                                                                                                                                                                                             
e2.AjoutElm(c1);                                                                                                                                                                                             
cout<<"Contenu du tableau element après l'ajout d'objets de type Carafe : "<<endl;                                                                                                                           
e.Afficher();                                                                                                                                                                                                
                                                                                                                                                                                                             
                                                                                                                                                                                                             
//Destruction d'un élément                                                                                                                                                                                   
e.DetruireElm(c2);                                                                                                                                                                                           
cout<<"Contenu du tableau element après suppression d'un objet: "<<endl;                                                                                                                                     
e.Afficher();                                                                                                                                                                                                
                                                                                                                                                                                                             
                                                                                                                                                                                                             
//test d'appartenance                                                                                                                                                                                        
if(e.isSubset(e2)==true)                                                                                                                                                                                     
	{                                                                                                                                                                                                        
	cout<<"l'ensemble 2 est un sous-ensemble de l'ensemble 1 "<<endl;                                                                                                                                        
	}                                                                                                                                                                                                        
                                                                                                                                                                                                             
 //Union de deux ensembles
e1=e.buildunion(e2);
cout<<"RÉSULTAT UNION :"<<endl;
e1.Afficher();

//Intersection de deux ensembles
e1=e.getIntersection(e2);
cout<<"RÉSULTAT INTERSECTION: "<<endl;
e1.Afficher(); //NOTEZ QUE LES CASES VIDES DU TABLEAU ELEMENT SERONT REMPLIES PAR DES OBJETS AVEC UNE VALEUR DE 0.0

                                                                                                                                                                                                            
return 0;                                                                                                                                                                                                    
                                                                                                                                                                                                             
}                                                                                                                                                                                                            
                                                                                                                                                                                                             