
#include <iostream> 
using namespace std;

class Date {
    private:
        int annee;
        int mois;
        int jour;
    public:

    Date(int j, int m, int a);

    void Afficher();

    

    void Lire();
   friend void operator++( Date& ,int); // peut être déclarée comme fonction membre également
   // la déclaration de la fonction de surcharge operator<< et operator>> comme fonction amie est obligatoire 
   friend ostream& operator<<(ostream & ,Date& ); 
   bool operator==(Date); // peut être déclarée comme fonction amie également
};
