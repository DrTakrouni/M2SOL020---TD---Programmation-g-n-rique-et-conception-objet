#include <iostream> 
#include "Date.h"

using namespace std;

int main()
{   
Date d1(1,1,1);
Date d2(0,0,0);

 d1.Lire();
 d1++;
 cout<<d1<<endl;

 if(d1==d2)
    	cout<<d1<<" et "<<d2<<" sont égales"<<endl;
 else
	 	cout<<d1<<" et "<<d2<<" ne sont pas égales"<<endl;
return 0;
}
