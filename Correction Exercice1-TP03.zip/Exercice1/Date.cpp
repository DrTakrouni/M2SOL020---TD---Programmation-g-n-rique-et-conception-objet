#include"Date.h"
#include<iostream>

 Date::Date(int j, int m, int a) {
            this->jour = j;
            this->mois = m;
            this->annee = a;
    }

void Date::Afficher() {
	cout << jour << " " << " " << mois << " " << annee;
	}


   void Date::Lire() {// méthode lecture d'une date
       cout << "Entrez le jour";
       cin >> jour;
       cout << "Entrez le mois";
       cin >> mois;
       cout << "Entrez l'année ";
       cin >> annee;
		}
// Exercice 1-1
void operator++( Date& d,int){ // le 2eme paramètre int est obligatoire pour indiquer qu'il s'agit d'une post incrementation
	       int lmois[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	       if (((d.annee % 4) == 0) && ((d.annee % 400) != 0)) lmois[1]++;
	       d.jour++;
	       if (d.jour > lmois[d.mois-1]) {
	           d.jour = 1; d.mois ++;
	           if (d.mois == 13) {d.annee++; d.mois = 1;}
	           }

}
// Exercice 1-2
ostream& operator<<(ostream& os, Date& d){

	cout<<d.jour<<"/"<<d.mois<<"/"<<d.annee;
	return os;

}
// Exercice 1-3
bool Date::operator==(Date d){
	if(this->jour == d.jour)
		return true;
}
