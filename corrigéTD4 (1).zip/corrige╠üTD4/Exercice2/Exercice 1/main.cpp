#include <iostream>
#include "Ensemble.h"
using namespace std;
int main()
{
Carafe c1(1,6);
Carafe c2(2,3);

Ensemble<Carafe> e;//Initialisation du patron de classe Ensemble avec la classe Carafe; ceci implique l'initialisation du tableau "element" de la classe Ensemble par des objets vides de type Carafe
e.AjoutElm(c1);
e.AjoutElm(c2);
e.AjoutElm(c1);
cout<<"Contenu du tableau element après l'ajoute de 3 objets de type Carafe : "<<endl;
e.Afficher();

e.DetruireElm(c2);
cout<<"Contenu du tableau element après suppression d'un objet: "<<endl;
e.Afficher();
}
