#include <iostream>
using namespace std;
class Carafe {
    private:
    int contenu;
    int capacite;

    public:
    Carafe(int contenu,int capacite) ;
    void remplir();
    void vider();
    int Contenu();
    int Capacite();
    friend ostream& operator<<(ostream& os, Carafe& c);
    void transvaser(Carafe c);
    Carafe* operator+=(int);
    Carafe* operator-=(int);
    Carafe operator+=(Carafe c);
    bool operator==(Carafe c); //Modification 1: afin de pouvoir pour comparer deux objets de type Carafe (if elements[i]==T())
    Carafe();//Modification 2: l'ajout d'un constructeur par défaut est nécessaire ici afin de pouvoir créer des objets vides de type Carafe ( ex: T(), T étant le type générique )


    };
