#include "Etudiant.h"
#include <iostream>
using namespace std;


void Etudiant::Afficher(){
	cout<<"le nom de l'etudiant: "<<nom<<endl;
	cout<<"le prenom de l'etudiant: "<<prenom<<endl;
}


Etudiant::Etudiant(string nom, string prenom, float note)
{
	this->nom=nom;
	this->prenom=prenom;
	this->note=note;
}
