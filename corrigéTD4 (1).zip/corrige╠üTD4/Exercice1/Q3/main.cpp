#include "Etudiant.h"
#include <iostream>
using namespace std;

int main()
{
	Etudiant e1("Toto", "Toto", 18);
	Etudiant e2("Titi", "Titi", 12);
	cout<<"Les noms des étudiants avant Swap:"<<endl;
	e1.Afficher();
	e2.Afficher();
	swap(e1,e2);
	cout<<"Les noms des étudiants après Swap:"<<endl;
	e1.Afficher();
	e2.Afficher();

	return 0;
}
template <typename T>
void swap(T& e1,T& e2)
{	T temp; // si le patron est instanciée avec un objet de type classe (Etudiant, Date,..), cette ligne fera appel au constructeur de la classe en question
	temp=e1;
	e1=e2;
}

