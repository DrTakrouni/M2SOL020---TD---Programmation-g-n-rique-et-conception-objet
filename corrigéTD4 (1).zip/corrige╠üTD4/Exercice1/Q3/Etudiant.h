using namespace std;
#include <string>;


class Etudiant{
public:
	void Afficher();
	Etudiant(string, string, float);
private:
	string nom;
	string prenom;
	float note;

};
