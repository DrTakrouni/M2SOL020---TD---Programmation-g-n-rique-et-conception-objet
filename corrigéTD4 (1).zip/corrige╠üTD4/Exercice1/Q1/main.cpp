#include <iostream>
using namespace std;
int main()
{
float a,b;
a=10;
b=20;
cout<<"a avant swap : "<<a<<endl;
cout<<"b avant swap : "<<b<<endl;

swap(a,b);

cout<<"a après swap : "<<a<<endl;
cout<<"b après swap : "<<b<<endl;


	return 0;
}
template <typename T>
void swap(T& e1,T& e2) 
{	T temp; 
	temp=e1;
	e1=e2;
}

