#include <iostream>
#include "Date.h"
using namespace std;


int main()
{
Date d1(01,01,2024);
Date d2(12,12,2024);

swap(d1,d2);
cout<<"les nouvelles dates après Swap : "<<endl;
cout<<d1<<endl; //cette ligne fera appel à la fonction operator<< déclarée dans la class Date
cout<<d2<<endl; //cette ligne fera appel à la fonction operator<< déclarée dans la class Date
return 0;
}


template <typename T>
void swap(T& x, T& y)
{
	T temp=x;
	x=y;
	y=temp;
}



