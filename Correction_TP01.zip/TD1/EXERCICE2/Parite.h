bool Parite(short);
