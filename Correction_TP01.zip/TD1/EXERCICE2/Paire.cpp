#include <iostream>
#include "Paire.h"
using namespace std;


int main(){
	cout<<"Entrez un nombre: ";
	int nb;
	cin>>nb;
	bool resultat= Parite(nb);
	if (resultat) //resultat == 1
		cout<<nb<<" est impair";
	else //resultat == 0
		cout<<nb<<" est pair";
return 0;
}
