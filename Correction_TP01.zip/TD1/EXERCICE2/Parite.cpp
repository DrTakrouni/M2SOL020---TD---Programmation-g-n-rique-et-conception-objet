
#include "Parite.h"

bool Parite(short nb)
{
	if(nb%2)
		return false;
	else
		return true;
}
