

#include <iostream>
#include <string>

using namespace std;

int main()
{	string nom;
	cout << "Entrez votre nom: ";
	cin  >> nom;
	cout << "Bonjour "<< nom <<endl;
	return 0;
}


