#include <iostream> 
#include "Date.h"

using namespace std;

int main()
{   Date d(01,01,01);
    d.Afficher(); // affiche 01/01/01
    d.Lire();
    d.Incrementer();
    d.Afficher();
    
	return 0;
}