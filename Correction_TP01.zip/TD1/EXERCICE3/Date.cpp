#include <iostream>
#include "Date.h"
using namespace std;

 Date::Date(int j, int m, int a) {
            this->jour = j;
            this->mois = m;
            this->annee = a;
    }

 void  Date::Afficher() { 
		cout << jour << "/" << "/" << mois << "/" << annee<<endl; 
		}

 void  Date::Incrementer() {
        // Pas de taille indiquée dans la déclaration des tableaux
        int lmois[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        // prise en compte des annees bissextiles
        if (((annee % 4) == 0) && ((annee % 400) != 0)) lmois[1]++;
        jour++;
        if (jour > lmois[mois-1]) {
            jour = 1; mois ++;
            if (mois == 13) {annee++; mois = 1;}
            }
        }
    
 void  Date::Lire() {// méthode lecture d'une date
        cout << "Entrez le jour: ";
        cin >> jour;
        cout << "Entrez le mois: ";
        cin >> mois;
        cout << "Entrez l'année: ";
        cin >> annee;
	}