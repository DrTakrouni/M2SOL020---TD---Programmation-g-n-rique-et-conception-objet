
#include <iostream> 
using namespace std;

class Date {

 private:
        int annee;
        int mois;
        int jour;
    
 public:
//Declaration des prototypes des méthodes de la class
    Date(int, int, int); // Prototype du constructeur de la class Date
    void Afficher();
    void Incrementer();
    void Lire();
};