#include <iostream>
#include <fstream>
#include <string>
using namespace std;


void verifier(ifstream &file){
	string ligne;
	getline(file, ligne);
    	cout << ligne << endl;
}

int main(){
	ofstream fichier1("naissance.txt",ios::out);  // ouverture en écriture avec effacement du fichier ouvert
	//pensez à remplacer iOS::out par iOS::app si vous ne souhaitez pas écraser le contenu du fichier
	string datenaissance;
	cout<<"entrez votre date de naissance: ";
	cin >> datenaissance;

	fichier1<<datenaissance<<endl;
	fichier1.close();
	ifstream fichier2("naissance.txt");  // ouverture en lecture
	fichier2.close();
	verifier(fichier2);


return 0;
}
