#include <iostream>
using namespace std;
#include "Carafe.h"

int main()
{
	Carafe c1(0,100);
	Carafe c2(50,100);
	c1+=40;//c1= 100
	cout<< "Le nouveau contenu est :" <<c1.Contenu()<<endl;
	c1-=100;// c1=0
	cout<< "Le nouveau contenu est :" <<c1.Contenu()<<endl;

	c1+=c2;//50
	cout<<"le nouveau contenu apres transvasion est : "<<c1.Contenu();
}
