#include <iostream>
using namespace std;

class Carafe {
private:
	int contenu;
	int capacite;
public:
	Carafe(int contenu,int capacite);
	//void remplir();
	void operator+=(int );
	//void vider();
	void operator-=(int);
	int Contenu();
	int Capacite();
	//void transvaser(Carafe c);
	void operator+=(Carafe );
};
