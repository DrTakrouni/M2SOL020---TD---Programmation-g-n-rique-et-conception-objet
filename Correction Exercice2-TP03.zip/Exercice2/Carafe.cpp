#include <iostream>
using namespace std;
#include "Carafe.h"

Carafe::Carafe(int contenu,int capacite) {
	this->contenu = contenu;
	this->capacite = capacite;
}
void Carafe::operator+=(int qte)
		{
		this->contenu = this->capacite;
		}
int Carafe::Contenu(){
	return this->contenu;
}

int Carafe::Capacite(){
	return capacite;
}

 /*void Carafe::vider() {
contenu = 0;
}*/

void Carafe::operator-=(int qte)
		{
		this->contenu=0;

		}
void Carafe::operator+=(Carafe car ){
	if(this->capacite >= this->contenu+car.contenu )
	{
		this->contenu+=car.contenu;
		car.contenu=0;
	}
	else
	{
		this->contenu=this->capacite;
	}


}









